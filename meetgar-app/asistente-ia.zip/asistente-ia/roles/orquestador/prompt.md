# Prompt del rol orquestador
