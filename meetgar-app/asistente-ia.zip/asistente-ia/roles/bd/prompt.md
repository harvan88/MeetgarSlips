# Prompt del rol bd
