// asistente-ia/shared/git.ts
import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

/** Devuelve el diff sin color; cadena vacía si no hay cambios */
export function getDiff(absPath: string): string {
  try {
    return execSync(`git diff --no-color -- ${absPath}`, { encoding: 'utf8' });
  } catch {
    return '';
  }
}

/** Devuelve el contenido actual del archivo */
export function getFileContent(absPath: string): string {
  return readFileSync(absPath, 'utf8');
}

/*  👇  Mantén además un default para compatibilidad con otros imports   */
export default { getDiff, getFileContent };
