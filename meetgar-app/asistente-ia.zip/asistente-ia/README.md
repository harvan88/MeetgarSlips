# Asistente IA – Meetgar

Guía rápida para levantar y usar el sistema de asistentes IA.