// bootstrap.ts - registra asistentes según assistants.json
