'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase/client'

export default function AuthCallback() {
  const router = useRouter()

  useEffect(() => {
    const handleExchange = async () => {
      const { error } = await supabase.auth.exchangeCodeForSession(window.location.href)
      if (error) {
        console.error('❌ Error al intercambiar sesión:', error.message)
        router.replace('/login?error=oauth')
        return
      }

      router.replace('/dashboard')
    }

    handleExchange()
  }, [router])

  return <p className="p-4 text-center text-sm">Procesando login...</p>
}
